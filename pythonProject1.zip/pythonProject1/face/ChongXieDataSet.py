# 重写DataSet
from torch.utils.data import ConcatDataset

class Dataset(object):
    def __getitem__(self, index):
        raise NotImplementedError

    def __add__(self, other):
        return ConcatDataset([self, other])