# 将label和像素数据分离
import pandas as pd

# 原数据路径
path = 'D://face/train.csv'
# 读取数据
df = pd.read_csv(path)
# 提取label数据
df_y = df[['label']]
# 提取feature（即像素）数据
df_x = df[['feature']]
# 将label写入label.csv
df_y.to_csv('D://face/label.csv', index=False, header=False)
# 将feature数据写入data.csv
df_x.to_csv('D://face/data.csv', index=False, header=False)